# kelas
class Marvel:
    pass

# object

marvel1 = Marvel()
marvel2 = Marvel()
marvel3 = Marvel()

marvel1.name = "Iron Man"
marvel1.health = "1000"

marvel2.name = "Thor"
marvel2.health = "800"

marvel3.name = "Captain America"
marvel3.health = "900"

# pemanggilan
print(marvel1)
print(marvel1.__dict__)
print(marvel1.name)
